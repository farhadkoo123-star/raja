# راه‌اندازی پایگاه داده Google Sheets برای رَجا

## ۱. ساخت Spreadsheet
1. وارد حساب Google شوید و در Google Drive گزینه **جدید → Google Sheets** را بزنید.
2. برای فایل نامی مثل «پایگاه داده رَجا» انتخاب کنید. فعلاً هیچ برگه‌ای را حذف نکنید.

## ۲. بازکردن Apps Script
از منوی بالای صفحه **Extensions → Apps Script** را انتخاب کنید تا پروژه‌ی متصل به همین Spreadsheet باز شود.

## ۳. قراردادن کد
در فایل `Code.gs` محتوای پیش‌فرض را پاک کنید، کد فایل `backend/Code.gs` این پروژه را کامل کپی کنید و ذخیره (Ctrl+S) کنید.

## ۴. ساخت شیت‌ها و سرستون‌ها
از فهرست توابع بالای محیط، `setupInitialSheets` را انتخاب و Run کنید. بار اول مجوزهای Google Sheets را تأیید کنید. شیت‌های Anthems، Classes، News، Stats، Registrations و Settings با سرستون و داده‌های نمونه ایجاد می‌شوند (محتوای شیت موجود بازنویسی نمی‌شود).

در Apps Script به **Project Settings → Script Properties** بروید و property با نام `RAJA_ADMIN_TOKEN` بسازید؛ مقدار آن را یک رشته‌ی طولانی و تصادفی انتخاب کنید. همان توکن باید در تنظیمات پنل مدیر وارد شود. توکن را عمومی نکنید. مقدار پیش‌فرض `CHANGE_ME` امن نیست و صرفاً fallback است.

## ۵. استقرار به صورت Web App
روی **Deploy → New deployment** بزنید، نوع **Web app** را انتخاب کنید، در **Execute as** گزینه **Me** و در **Who has access** گزینه **Anyone** را انتخاب کنید (در محیط سازمانی، مطابق سیاست‌های سازمان عمل کنید). Deploy را بزنید و مجوزها را تأیید کنید. پس از تغییر کد، برای اعمال نسخه جدید از **Deploy → Manage deployments → Edit → New version → Deploy** استفاده کنید.

## ۶. اتصال سایت
Web App URL که به `/exec` ختم می‌شود کپی کنید. `admin.html` را باز کنید، وارد تب **تنظیمات** شوید، URL را در فیلد Google Apps Script Web App URL و مقدار `RAJA_ADMIN_TOKEN` را در فیلد توکن وارد کنید، **ذخیره تنظیمات** و سپس **آزمون اتصال** را بزنید.

## نکات API و امنیت
- GETهای `getAll`, `getAnthems`, `getClasses`, `getNews`, `getStats`, `getRegistrations` داده را به شکل `{ok:true,data:...}` برمی‌گردانند؛ همه به‌جز `getAll` عمومی هستند.
- POST با JSON و فیلدهای `action`, `token`, `table`, `data`, `id` و عملیات `create`, `update`, `delete`, `register` انجام می‌شود. Apps Script پاسخ JSON می‌دهد و Data هم در مرورگر به‌صورت cache/local fallback نگه‌داری می‌شود.
- Google Apps Script ممکن است هدرهای CORS سفارشی را اجازه ندهد؛ ContentService در کد پاسخ JSON استاندارد می‌سازد و معمولاً برای Web App از مرورگر کار می‌کند. `mode: no-cors` نگذارید چون پاسخ قابل خواندن نیست.
- GET ثبت‌نام‌ها برای کاربرد بدون احراز هویت، خصوصی محسوب نمی‌شود. اگر درخواست‌ها حاوی اطلاعات شخصی هستند دسترسی و معماری احراز هویت را امن‌سازی کنید؛ URL عمومی را به‌عنوان مرز امنیت فرض نکنید.

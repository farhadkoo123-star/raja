/** Raja Cultural Website — Google Sheets JSON API
 * Set Script Properties: RAJA_ADMIN_TOKEN to a long random secret.
 * Deploy as Web App; execute as you; limit access to Anyone only when appropriate.
 */
const TABLES = {
  Anthems: ['id','title','category','cat','label','desc','duration','audioUrl','year','featured','icon'],
  Classes: ['id','title','category','cat','desc','age','schedule','place','status','icon'],
  News: ['id','type','title','date','tag','desc','place'],
  Stats: ['id','label','value','suffix'],
  Registrations: ['id','name','phone','course','message','createdAt','status'],
  Settings: ['key','value']
};
const SEEDS = {
  Anthems: [{id:1,title:'نماهنگ مناسبتی رَجا',desc:'نخستین اثر استودیویی مجموعه رَجا.',cat:'religious',label:'مذهبی و ولایی',duration:'۳:۲۴',audioUrl:''},{id:2,title:'سرود ملی میهنی ایران',desc:'اثری پرشور و حماسی.',cat:'national',label:'ملی و حماسی',duration:'۳:۱۰',audioUrl:''}],
  Classes: [{id:1,title:'اصول سرود و همخوانی',desc:'آموزش سلفژ، کوک صدا و فنون اجرا.',age:'۱۲ تا ۱۸ سال',schedule:'شنبه و دوشنبه',place:'خانه فرهنگ رَجا'},{id:2,title:'تصویربرداری و تدوین',desc:'آموزش رسانه و تدوین.',age:'۱۴ تا ۲۰ سال',schedule:'یکشنبه',place:'کارگاه رسانه رَجا'}],
  News: [{id:1,type:'news',title:'فراخوان عضویت رَجا',date:'۱۴۰۳/۰۶/۲۰',tag:'اطلاعیه',desc:'ثبت‌نام دوره جدید آغاز شد.'}],
  Stats: [{id:'members',label:'عضو و هنرجو',value:120},{id:'programs',label:'اجرای فرهنگی',value:18},{id:'anthems',label:'اثر تولیدشده',value:6},{id:'classes',label:'کارگاه تخصصی',value:12}],
  Registrations: [], Settings: [{key:'adminToken',value:'CHANGE_ME'}]
};
function json_(obj) { return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }
function spreadsheet_() { const id=PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID'); return id ? SpreadsheetApp.openById(id) : SpreadsheetApp.getActiveSpreadsheet(); }
function setupInitialSheets() {
  const ss=spreadsheet_(); if (!ss) throw new Error('ابتدا Spreadsheet را به این Apps Script متصل کنید.');
  Object.keys(TABLES).forEach(name=>{let sh=ss.getSheetByName(name);if(!sh)sh=ss.insertSheet(name);const headers=TABLES[name];if(sh.getLastRow()===0){sh.getRange(1,1,1,headers.length).setValues([headers]);sh.setFrozenRows(1);if(SEEDS[name]&&SEEDS[name].length)writeObjects_(sh,headers,SEEDS[name]);}else{const got=sh.getRange(1,1,1,Math.max(sh.getLastColumn(),headers.length)).getValues()[0];if(got.filter(String).length===0)sh.getRange(1,1,1,headers.length).setValues([headers]);sh.setFrozenRows(1);}});
  // Secret is kept in Script Properties, never exposed by GET.
  if(!PropertiesService.getScriptProperties().getProperty('RAJA_ADMIN_TOKEN'))PropertiesService.getScriptProperties().setProperty('RAJA_ADMIN_TOKEN',Utilities.getUuid()+Utilities.getUuid());
  return 'Sheets and headers ready.';
}
function doGet(e) {
  try { const action=(e&&e.parameter&&e.parameter.action)||'getAll'; const map={getAll:null,getAnthems:'Anthems',getClasses:'Classes',getNews:'News',getStats:'Stats',getRegistrations:'Registrations'};
    if(!(action in map))return json_({ok:false,error:'Unknown action'});
    if(action==='getAll'){const all={};Object.keys(TABLES).forEach(t=>{if(t!=='Settings')all[t[0].toLowerCase()+t.slice(1)]=readTable_(t)});return json_({ok:true,data:all});}
    const rows=readTable_(map[action]);return json_({ok:true,data:rows});
  } catch(err){return json_({ok:false,error:String(err.message||err)});}
}
function doPost(e) {
  try { const body=JSON.parse((e&&e.postData&&e.postData.contents)||'{}');const action=String(body.action||'');const table=normalizeTable_(body.table||body.entity);const data=body.data;authenticate_(body.token);
    if(action==='register'){const row=Object.assign({},data||{});row.id=row.id||Utilities.getUuid();row.createdAt=row.createdAt||new Date().toISOString();row.status=row.status||'جدید';appendObject_('Registrations',row);return json_({ok:true,data:row});}
    if(!table||table==='Settings')throw new Error('جدول نامعتبر است.');
    if(action==='create'){const row=Object.assign({},data||{});row.id=row.id||Utilities.getUuid();appendObject_(table,row);return json_({ok:true,data:row});}
    if(action==='update'){const id=body.id!=null?body.id:(data&&data.id);if(id==null)throw new Error('شناسه برای ویرایش الزامی است.');const row=Object.assign({},data||{},{id:id});if(!updateObject_(table,id,row))throw new Error('رکورد پیدا نشد.');return json_({ok:true,data:row});}
    if(action==='delete'){if(body.id==null)throw new Error('شناسه برای حذف الزامی است.');const deleted=deleteObject_(table,body.id);return json_({ok:true,data:{deleted:deleted}});}
    throw new Error('عملیات نامعتبر است.');
  } catch(err){return json_({ok:false,error:String(err.message||err)});}
}
function normalizeTable_(name){if(!name)return '';const n=String(name);const alias={anthems:'Anthems',classes:'Classes',news:'News',stats:'Stats',registrations:'Registrations',settings:'Settings'};return alias[n.toLowerCase()]|| (TABLES[n]?n:'');}
function authenticate_(token){const expected=PropertiesService.getScriptProperties().getProperty('RAJA_ADMIN_TOKEN')||'CHANGE_ME';if(!token||token!==expected)throw new Error('توکن مدیریت نامعتبر است. در Script Properties مقدار RAJA_ADMIN_TOKEN را تنظیم کنید.');}
function readTable_(name){const sh=spreadsheet_().getSheetByName(name);if(!sh||sh.getLastRow()<2)return [];const values=sh.getDataRange().getValues(),headers=values.shift().map(String);return values.filter(row=>row.some(v=>v!==''&&v!==null)).map(row=>rowToObject_(headers,row));}
function rowToObject_(headers,row){const obj={};headers.forEach((h,i)=>{if(h)obj[h]=row[i] instanceof Date?row[i].toISOString():row[i];});return obj;}
function writeObjects_(sh,headers,objects){if(!objects.length)return;sh.getRange(sh.getLastRow()+1,1,objects.length,headers.length).setValues(objects.map(o=>objectToRow_(headers,o)));}
function objectToRow_(headers,obj){return headers.map(h=>{let v=obj[h];if(v===undefined||v===null)return '';if(typeof v==='object')return JSON.stringify(v);return v;});}
function appendObject_(name,obj){const sh=spreadsheet_().getSheetByName(name);if(!sh)throw new Error('شیت '+name+' موجود نیست؛ setupInitialSheets را اجرا کنید.');const headers=TABLES[name];sh.appendRow(objectToRow_(headers,obj));}
function updateObject_(name,id,obj){const sh=spreadsheet_().getSheetByName(name);if(!sh)return false;const headers=TABLES[name];if(sh.getLastRow()<2)return false;const idCol=headers.indexOf('id')+1;if(!idCol)return false;const found=sh.getRange(2,idCol,sh.getLastRow()-1,1).createTextFinder(String(id)).matchEntireCell(true).findNext();if(!found)return false;sh.getRange(found.getRow(),1,1,headers.length).setValues([objectToRow_(headers,obj)]);return true;}
function deleteObject_(name,id){const sh=spreadsheet_().getSheetByName(name);if(!sh||sh.getLastRow()<2)return false;const col=TABLES[name].indexOf('id')+1;if(!col)return false;const found=sh.getRange(2,col,sh.getLastRow()-1,1).createTextFinder(String(id)).matchEntireCell(true).findNext();if(!found)return false;sh.deleteRow(found.getRow());return true;}
